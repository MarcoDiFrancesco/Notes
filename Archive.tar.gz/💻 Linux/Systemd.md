Using: systemd-boot
Not using: GRUB

Check settings: `bootctl`

Change boot order: *Just press 'd' for linux-zen during the 3 second boot menu.*

Order:
- Linux
- Linux LTS
- Linux ZEN: nvidia drivers not working