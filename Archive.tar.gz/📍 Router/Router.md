## Authentication
```
DiFra WiFi
4mostridaconche
```

## Port forwarding
Location: Network -> NAT -> Inoltro Porta
`nmap -v scanme.nmap.org` from eduroam to check open ports
- 8118 for [[Proxy - Privoxy]]
![[Pasted image 20221201150315.png]]

## Backup
Location: Manutenzione -> Salvataggio/Ripristino
Drive: Backups -> Router