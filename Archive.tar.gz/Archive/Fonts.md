# Fonts
*extra/noto-fonts*
- set as default soft liking it in *~/.config/fontconfig/conf.d/*
- used in *i3* config

Used by URXVT and VSCode (set terminal.integrated.fontFamily):
- *aur/nerd-fonts-inconsolata*

Used by Polybar:
- *ttf-font-awesome* for personalized icons

Fonts to test:
- *ttf-bitstream-vera*
- *ttf-dejavu*
