# Azure
Server choise for Django: [[Python - Django#Server]]

## Azure Cli
_aur/azure-cli_ for **Azure Cli**

`az` show all options

-   `configure` show current settings
	-   `--defaults mysettings=no` set config (all configs in [docs](https://docs.microsoft.com/en-us/cli/azure/azure-cli-configuration))

## Function App
_aur/azure-functions-core-tools-bin_ for **Function App**

`func azure` show all options

-   `storage fetch-connection-string` to get string to local
-   `functionapp list-functions botmeteotn-stationsdataloader` to list all functions in Function App
