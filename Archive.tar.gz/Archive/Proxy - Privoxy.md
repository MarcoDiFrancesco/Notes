Installed in raspberry - https://pimylifeup.com/raspberry-pi-proxy-using-privoxy/
**Port**: 8118 (default)
**Authentication**: is not possible
*/etc/privoxy/config*
```
listen-address :8118
# Aalto
permit-access  130.233.85.255/24
```
