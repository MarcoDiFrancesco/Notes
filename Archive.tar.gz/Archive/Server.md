Main server choises:
- **Nginx**: 15000 static files per second
- **Apache**: 3000 static files per second

Nginx is **faster**, but consider that **Django** can server 50 requests per second.
Apache has **better documentation** support as compared to Nginx.