nothing (normal):
$$
RQSZ
$$
`\mathrm` (roman)
$$
\mathrm{RQST}
$$
`\mathcal` (calligraphic):
$$
\mathcal{RQSZ}
$$
`\mathfrak` (dominating number?):
$$
\mathfrak{RQSZ}
$$
`\mathbb` (blackboard):
$$
\mathbb{RQSZ}
$$
