# Window manager
### I3
As windows manager *i3* is used

To open a floating window or full screen by default, the option for_window in config is used ([Reddit](https://www.reddit.com/r/i3wm/comments/4chax2/exec_with_fullscreen/)), to get the class name use xprop and click on the window ([Reddit](https://www.reddit.com/r/i3wm/comments/3h94t9/how_to_find_a_name_of_a_program_to_use_for/)).

Suspend and Auto lock in:

[[Sleep]]

- **Archive** Bspwm

### Bspwm
Removed because was not rendering Android Studio.
