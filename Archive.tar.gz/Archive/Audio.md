Options (Analog, Digital Stereo): Reddit says they are more or less the same.
- IEC958 is just a stardard that might be even removed.
- Analog supports everything that IEC958 supports.

![[Pasted image 20230114105858.png]]
